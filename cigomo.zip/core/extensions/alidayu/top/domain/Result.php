<?php

/**
 * 无
 * @author auto create
 */
class Result
{
	
	/** 
	 * 错误码
	 **/
	public $code;
	
	/** 
	 * 无
	 **/
	public $model;
	
	/** 
	 * 原因
	 **/
	public $msg;
	
	/** 
	 * 结果
	 **/
	public $success;	
}
?>