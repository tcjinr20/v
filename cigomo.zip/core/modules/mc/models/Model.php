<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/9 0009
 * Time: 15:41
 */

namespace app\modules\mc\models;

class Model extends \app\models\Model{


}