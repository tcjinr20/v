<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/9 0009
 * Time: 11:30
 */
namespace app\modules\mc\controllers;

class Controller extends \app\controllers\Controller {
    public $layout = 'main';
    public $store_id = 1;
}