
<?= $this->render('head.php') ?>
<?= $content ?>
<?= $this->render('foot.php') ?>
