<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/26
 * Time: 14:55
 */

namespace app\modules\api\controllers;


class CommentController extends Controller
{
    public function actionIndex()
    {

    }
}